package com.slabstech.revive.server.dropwizard.retrofit.rx

import java.io.IOException

object GithubRxApp {
    @Throws(IOException::class)
    @JvmStatic
    fun main(args: Array<String>) {
        val userName = "eugenp"
        GithubRxService().getTopContributors(userName).subscribe { x: String? -> println(x) }
    }
}