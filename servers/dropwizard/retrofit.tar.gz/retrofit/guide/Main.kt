package com.slabstech.revive.server.dropwizard.retrofit.guide

import com.slabstech.revive.server.dropwizard.retrofit.guide.GithubServiceGenerator.createService
import okhttp3.OkHttpClient.Builder.build
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import java.io.IOException

object Main {
    @JvmStatic
    fun main(args: Array<String>) {
        // Manual creation
        val httpClient = Builder()
        val retrofit =
            Retrofit.Builder().baseUrl("https://api.github.com/").addConverterFactory(GsonConverterFactory.create())
                .client(httpClient.build()).build()
        var service = retrofit.create(GithubUserService::class.java)
        // Using GitHubServiceGenerator
        service = createService(GithubUserService::class.java)
        val callSync = service.getGithubUser("sachinsshetty")
        val callAsync = service.getGithubUser("sachinsshetty")
        try {
            val response = callSync!!.execute()
            val GithubUser = response.body()
            println(GithubUser)
        } catch (ex: IOException) {
        }

        // Execute the call asynchronously. Get a positive or negative callback.
        callAsync!!.enqueue(object : Callback<GithubUser?> {
            override fun onResponse(call: Call<GithubUser?>, response: Response<GithubUser?>) {
                val githubUser = response.body()
                println(githubUser)
            }

            override fun onFailure(call: Call<GithubUser?>, throwable: Throwable) {
                println(throwable)
            }
        })
    }
}