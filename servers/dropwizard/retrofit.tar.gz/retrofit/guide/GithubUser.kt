package com.slabstech.revive.server.dropwizard.retrofit.guide

class GithubUser {
    var login: String? = null
    var id: Long = 0
    var url: String? = null
}